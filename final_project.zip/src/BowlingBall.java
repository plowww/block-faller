import java.awt.*;

/**
 * This is a bowling ball enemy. It acts the same as the player, but moves in one direction until it goes offscreen.
 * Essentially a bullet of some sort.
 * @author Kevin Gomes
 *
 */
public class BowlingBall extends Enemy{

	/**
	 * Default, same as Enemy.
	 */
	public BowlingBall()
	{
		super();
	}

	/**
	 * Our main constructor creates an enemy at a given x and y position,
	 * with a given width and height. It then takes a color and speed.
	 * @param xPos The x-coordinate of our enemy.
	 * @param yPos The y-coordinate of our enemy.
	 * @param w The width of our enemy.
	 * @param h The height of our enemy.
	 * @param c The color of our enemy.
	 * @param xS The x speed of our enemy.
	 * @param yS The y speed of our enemy.
	 */
	public BowlingBall(double xPos, double yPos, double w, double h, Color c, double xS, double yS)
	{
		super(xPos, yPos, w, h, c, xS, yS);
	}
	
	/**
	 * Move our bowling ball. Note that it does not use any entity.
	 * @param e The entity.
	 */
	public void move(Entity e) {
		x += xSpeed;
	}

	/**
	 * Draws our monster. This is represented as a ball.
	 */
	public void paint(Graphics pane) {
		pane.setColor(color);
		pane.fillOval((int)x, (int)y, (int)width, (int)height);
		
	}
}
