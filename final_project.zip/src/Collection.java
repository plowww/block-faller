/**
	Collection.java

		This class defines and implements a collection of data items.

		The implementation is based on a linked list of items.

		@author Kevin Gomes

 */

import java.awt.*;							//	AWT = "Abstract Window Toolkit"


public class Collection {

	/**
	 * This is the reference to the first Node.
	 */
	private Node head;

	/**
	 * To keep track of where we are in the list.
	 */
	Node selected;

	/**
	 * The default constructor creates a collection with the default size.
	 */
	public Collection()
	{
		head = null;						// Our node is null to start.
		selected = null;
	}

	/**
	 *	a d d
	 *	=====
	 *
	 *	Adds the given entity to the collection. We also select this one.
	 *  @param someItem The entity we will add.
	 */
	public void add(Entity someItem)
	{
		Node holder = new Node(someItem, head);
		holder.setNext(head);
		head = holder;
		selected = holder;

	}

	/**
	 *	r e m o v e
	 *	===========
	 *
	 *	Removes a entity (if any).
	 */
	public void remove()
	{	
		if (isEmpty())
			System.out.println("The list is empty! Try creating something.");

		else
			head = head.getNext();
	}

	/**
	 * This remove method removes a specific entity. It will be used when platforms raise
	 * to the top of the screen, to keep the collection tidy.
	 * @param e The entity we will remove.
	 */
	public void remove(Entity e)
	{
		if (!isEmpty())

		{
			Node previous = null;
			Node current = head;

			while (current != null && !(current.getItem().equals(e)))
			{
				previous = current;
				current = current.getNext();
			}

			if (previous == null)
				current = null;
			else if (current != null && current.getItem().equals(e))
				previous.setNext(current.getNext());
			else
				System.out.println("Item not in list!");
			//Sets the next node of the node before
			//the node with our item to the one after our item...
			//<n> <e> <n2> <null> becomes <n> <n2> <null>
		}
	}

	/**
	 * Next returns us the currently selected node. It then moves to the next one.
	 * @return The node that is currently selected.
	 */
	public Node next()
	{
		Node result = null; //To ensure we return something
		if (selected != null) //If it were, we would return null, as there is no selected node.
		{
			result = selected; //Store our result into a temp reference.
			selected = selected.getNext(); //Move over.
		}

		return result;
	}

	/**
	 * This method tells us if the next() method will return us a node.
	 * @return Whether we have a next node.
	 */
	public boolean hasNext()
	{
		return selected != null; //Tells us if the selected node is null.
		//If it isn't, we have a node to return using the next() method.
	}

	/**
	 * Reset simply selects the first node in our list.
	 */
	public void reset()
	{
		selected = head; //Makes the selected node the first node in our list.
	}

	/**
	 * This will call our main mergeSort method with the head.
	 */
	public void sort()
	{
		head = quickSort(head);
	}
	
	/**
	 *	The following method sorts a list using quicksort sort of a sort.
	 *	By Kevin Gomes and Theresa Truong
	 *	03/30/2016
	 *	@param someHead The head of our list.
	 *	@return The method invocation combine.
	 */
	private Node quickSort(Node someHead)
	{
		Node result; //What we are returning at the end.

		if(someHead == null || someHead.getNext() == null) 
		//^ If the list is either empty or only has one item, nothing to sort!
			return someHead;

		else
		{
			Node pivot, smaller, smallerHead, larger, largerHead, temp;
			pivot = someHead; //This will always stay as this, so we may compare everything to it
			temp = someHead.getNext(); //What we are using to compare
			pivot.setNext(null); //The pivot is its own list of 1 item, thus no node should be after.
			smallerHead = largerHead = null; //The heads are null at first
			smaller = smallerHead;
			larger = largerHead;

			while(temp != null)
			{
				if(pivot.getItem().compareToWidth(temp.getItem()) > 0) 
					//If pivot item is greater than temp's item
				{
					if(smallerHead == null)
					{
						smaller = temp; //If there's no head for the small list, make it temp.
						smallerHead = smaller;
					}
					else
					{
						smaller.setNext(temp); //If there's a head, there's a list. Now refer to temp.
						smaller = smaller.getNext(); //Move to the next node
					}
				}
				else
				{
					if(largerHead == null)
					{
						larger = temp;
						largerHead = larger;
					}
					else
					{
						larger.setNext(temp); //If there's a head, there's a list. Now refer to temp.
						larger = larger.getNext(); //Move to the next node
					}
				}
				temp = temp.getNext();
			}

			if (smaller != null)
				smaller.setNext(null);
			if (larger != null)
				larger.setNext(null);

			smallerHead = quickSort(smallerHead); //Go through method again with small list's head
			largerHead = quickSort(largerHead);

			result = combine(combine(smallerHead, pivot), largerHead);
			//^ This combines the small list, the pivot, and the large list.

			return result;
		}

	}

	/**
	 * 	This is a helper of the quicksort method. Combines the two linked lists.
	 * 	By Kevin Gomes and Theresa Truong
	 *	03/30/2016
	 * 	@param headOne The first half of the list.
	 * 	@param headTwo The half after the pivot.
	 * 	@return The combined list.
	 */
	private Node combine(Node headOne, Node headTwo)
	{
		Node temp = headOne;
		Node tempHead = headOne; //To keep the head

		if(headOne == null)
			return headTwo; //As there is no list to combine to.

		while(temp.getNext() != null) //While the node after temp is not null
			temp = temp.getNext(); //This goes to the last node in the list referenced by temp

		temp.setNext(headTwo); //Because temp is the last node in first list, make the one after
								  //(the null) the secondNode, which is the head of the second list.

		return tempHead; //Effectively returns head of first list which has both lists combined
	}
	
	/*
	 								* UNEEDED CODE, BUT RESERVED FOR FUTURE
	 * 
	/**
	 * This method will sort our list with O(nlogn) amount of work. It will be used to sort
	 * the platforms by width, and the hazards by difficulty. It will recursively sort.
	 * @param head The linked list that is to be sorted.
	 * @return The merged sorted list.
	 */
	/*
	 * MORE UNEEDED CODE, MERGESORT DOES NOT WORK
	 *
	private Node mergeSort(Node head)
	{
		if (head == null || head.getNext() == null)
			return head; //Either returns null or first item.

		int size = length(head);
		Node newHeadOne = head;
		Node newHeadTwo = head;
		Node headOne = head;
		Node headTwo = headOne.getNext();
		for (int i = 0; i < size/2; i++)
		{
			if (headOne.getItem().compareToWidth(headTwo.getItem()) < 0)
			{
				newHeadOne.setNext(headOne.getNext());
			}

			else
			{
				newHeadOne.setNext(headTwo.getNext());
			}
		}

		for (int i = 0; i < size - (size/2); i++)
		{
			if (headOne.getItem().compareToWidth(headTwo.getItem()) < 0)
			{
				newHeadTwo.setNext(headOne.getNext());
			}

			else
			{
				newHeadTwo.setNext(headTwo.getNext());
			}
		}

		return merge(newHeadOne, newHeadTwo);
	}

	/**
	 * This method takes two heads, which are two linked lists, and merges them.
	 * It is a helper of mergeSort, and thus is private. This method assumes
	 * that the two heads are already sorted lists.
	 * @param headOne The first linked list.
	 * @param headTwo The second linked list.
	 * @return The complete list with headTwo being the middle of the list.
	 */
	
	/*
	 * MORE UNEEDED CODE
	 *
	private Node merge(Node headOne, Node headTwo)
	{
		if (headOne == null)
			return headTwo;
		if (headTwo == null)
			return headOne;

		if (headOne.getItem().compareToWidth(headTwo.getItem()) <= 0)
		{
			headOne.setNext(merge(headOne.getNext(), headTwo));
			return headOne;
		}

		else
		{
			headTwo.setNext(merge(headOne, headTwo.getNext()));
			return headTwo;
		}

	} 											END UNEEDED CODE */

	/**
	 * This checks if our collection is empty.
	 * @return whether we are empty.
	 */
	public boolean isEmpty()
	{
		return head == null;
	}

	/**
	 * This paints every node's entity in our collection.
	 * @param pane For drawing.
	 */
	public void paint(Graphics pane)
	{
		if (!isEmpty()){
			Node current = head;

			while (current != null)
			{
				current.paint(pane);
				current = current.getNext();
			}	
		}
	}

} //End Class
