
/**
 *	This simply makes our game for us to play.
 */
public class Program
{
	public static void main(String[] args){
		//Create our game.
		Game mainGame = new Game();
	}
}
