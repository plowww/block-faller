import java.awt.*;

/**
 * This is our player character. This class will determine most of the attributes and behavior of
 * our player. The interaction between us and other objects will be defined in those objects. 
 * In other words, every object will have to define its interaction with us.
 * @author Kevin Gomes
 *
 */
public class Player extends Entity {
	
	/**
	 * This will be our movement speed, in the x plane.
	 */
	private double xSpeed;
	
	/**
	 * This will be our speed in the y plane. It will also be used for jumping.
	 */
	private double ySpeed;
	
	
	/**
	 * This will tell us whether or not we are on solid ground.
	 */
	private boolean onLand;
	
	/**
	 * Since we are on earth, gravity plays a role at all times. It is constant, and jumping
	 * is defying it, so this constant will always decrease our ySpeed.
	 */
	public final double GRAVITY = 0.98;
	
	/**
	 * This is our maximum Y velocity.
	 */
	public final double MAX_Y_SPEED = 30;
	
	/**
	 * This creates us at the top left, with width and height 20, and black color. Our
	 * speeds are 0.
	 */
	public Player()
	{
		super();
		xSpeed = 15;
		ySpeed = 5;
		onLand = false;
	}
	
	/**
	 * Our main constructor creates a player at a given x and y position,
	 * with a given width and height. It then takes a color and speed values.
	 * @param x The x-coordinate of our player.
	 * @param y The y-coordinate of our player.
	 * @param w The width of our player.
	 * @param h The height of our player.
	 * @param c The color of our player.
	 */
	public Player(double x, double y, double w, double h, Color c)
	{
		super(x, y, w, h, c);
		xSpeed = 15;
		ySpeed = 5;
		onLand = false;
	}
	
	/**
	 * This method is continuously run to make sure we are always falling. This check is needed
	 * to ensure we fall whenever we are not on a platform.
	 */
	public void move()
	{
		if (!onLand)
		{
			fall();
		}
		
		else
		{
			ySpeed = 5;
			onLand = false;
		}
	}
	
	/**
	 * This moves our player to the left at our xSpeed.
	 */
	public void moveLeft()
	{
		x -= xSpeed;
	}
	
	/**
	 * This moves our player to the right at our xSpeed.
	 */
	public void moveRight()
	{
		x += xSpeed;
	}
	
	/**
	 * Keeps our player on top of entity e.
	 * @param e The entity we wish to stay on.
	 */
	public void stayOnTop(Entity e)
	{
		double eTopLeft = e.getY();
		y = eTopLeft - height;
	}
	
	/**
	 * This serves to break up the jump and fall operations.
	 * This is only for clarity, as it is very easy to include this in our jump method.
	 * This method makes our player fall by decreasing our ySpeed by gravity and our y by our speed.
	 */
	public void fall()
	{	
		y += ySpeed;
		ySpeed += GRAVITY;
		
		if (ySpeed > MAX_Y_SPEED)
			ySpeed = MAX_Y_SPEED;
	}
	
	/**
	 * This method will be invoked whenever we land, causing our ySpeed to remain at 0.
	 */
	public void land()
	{
		onLand = true;
	}
	
	/**
	 * To print out the items of interest of our player.
	 */
	public String toString()
	{
		String s = "x: " + x + ", y: " + y + ", width: " + width + ", height: " + height + ", color: " + color;
		s = s + ", ySpeed: " + ySpeed;
		return s;
	}
	
	/**
	 * This will draw our character. It will be a square.
	 * @param pane For drawing.
	 */
	public void paint(Graphics pane)
	{
		pane.setColor(Color.black);
		pane.drawRect((int)(x), (int)(y), (int)width, (int)height);
		pane.setColor(color);
		pane.fillRect((int)(x + 1), (int)(y + 1), (int)(width - 1), (int)(height - 1));
	}
}
