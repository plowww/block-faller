import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.sound.sampled.*;

import javax.imageio.*;

/**
 * This is the game class. It will define the behavior of the game, including buttons, 
 * what platforms are where, how many obstacles, etc. It also defines what happens when the player dies,
 * the score of the current game session, and other parts that make up our game.
 * Our game uses a mouse for the buttons at the beginning, and a keyboard for movement.
 * @author Kevin Gomes
 *
 */
public class Game extends Canvas implements MouseListener, AlarmListener, KeyListener
{
	/**
	 * Our buffer, for drawing
	 */
	private BufferStrategy buffer;

	/**
	 *  Our window.
	 */
	private Window myWindow;

	/**
	 * The alarm that is associated with animation.
	 */
	private Alarm alarm;			//	We use an alarm to wake us up

	/**
	 * While the game is running, this should be true.
	 */
	private boolean running;		//	Are we running?

	/**
	 * These are our difficulty buttons, which will change the size of our player.
	 */
	private Abutton easyB, mediumB, hardB, vHardB, questionB;

	/**
	 * These will change our player's color.
	 */
	private Abutton redB, greenB, blueB, magentaB, whiteB, transB;

	/**
	 * This will be our collection of platforms.
	 */
	private Collection platforms;

	/**
	 * This is our collection of hazards.
	 */
	private Collection enemies;

	/**
	 * The player's color.
	 */
	private Color playerColor;

	/**
	 * The background of the game.
	 */
	private Color bgColor;

	/**
	 * This keeps our mouse's location.
	 */
	private int lastX, lastY;		//	To keep the mouse location

	/**
	 * Keeps track of the number of platforms.
	 */
	private int totalPlatforms;

	/**
	 * Keeps track of the number of enemies on the screen at a time.
	 */
	private int totalEnemies;

	/**
	 * Speed of animation.
	 */
	private int delay;				// The speed of the animation.

	/**
	 * Our difficulty, represented as a number.
	 */
	private double difficulty;

	/**
	 * Our score. This increases at a rate relative to difficulty and
	 * how far or close the player is to the top or bottom of the screen.
	 */
	private long score;

	/**
	 * The total time that has elapsed.
	 */
	private double time;

	/**
	 * The highest time we have lasted.
	 */
	private double highTime;

	/**
	 * Our highest score in the game.
	 */
	private long highScore;

	/**
	 * Our player character;
	 */
	private Player player;

	/**
	 * These booleans are for smooth keyboard movement. Without these, movement feels static-like and
	 * choppy. These are needed for constant method calling, which in turn creates a smooth movement flow.
	 */
	private boolean left, right;

	/**
	 * This tells us a key is currently pressed. This allows us to avoid the constant effect of the keyPressed
	 * method.
	 */
	private boolean keyPressed;

	/**
	 * This will tell us whether we are in heaven or hell. It's mainly used for the background.
	 */
	private boolean heaven;

	/**
	 * The screen's width.
	 */
	public static final int SCREEN_WIDTH = 800;

	/**
	 * The screen's height.
	 */
	public static final int SCREEN_HEIGHT = 600; //Keep size of screen.

	/**
	 * Default sets us up completely. Some code taken from CSC 211, including comments.
	 */
	public Game()
	{
		Frame wind = new Frame("Perilous Platform Pacer (p cubed)");
		wind.setLocation(200, 0);
		wind.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
		setBounds(0, 0, SCREEN_WIDTH - 11, SCREEN_HEIGHT - 11);

		//starts out painting normally - painting will be taken over
		//by the takeNotice() method when the animation is running
		setIgnoreRepaint(false);

		//makes our Canvas the component held in the Frame
		wind.add(this);

		//starts out painting normally - painting will be taken over
		//by the takeNotice() method when the animation is running
		setIgnoreRepaint(false);

		//For our keyboard to work
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);

		myWindow = new Window();//to allow for window closing
		wind.addWindowListener(myWindow);

		//to handle mouse clicks
		addMouseListener(this);
		bgColor = new Color(0, 255, 255);

		//sets everything up to be visible
		wind.pack();
		wind.setResizable(false);
		wind.setVisible(true);

		setup();
	}

	/**
	 * A nice helper to help break up the setting up of the game. This sets up buttons and other stuff
	 * unrelated to the frame, window, etc.
	 */
	private void setup()
	{	
		//This block creates our buttons.
		int x = 20;
		int y = SCREEN_HEIGHT - 40;


		//For every button, add to x the button's width * 1.5, to have neat spacing.
		easyB = new Abutton("Easy", Color.green, x, y);
		x += Abutton.BUTTON_WIDTH * 1.5;
		mediumB = new Abutton("Medium", Color.yellow, x, y);
		x += Abutton.BUTTON_WIDTH * 1.5;
		hardB = new Abutton("Hard", Color.orange, x, y);
		x += Abutton.BUTTON_WIDTH * 1.5;
		vHardB = new Abutton("Very Hard", Color.red, x, y);
		questionB = new Abutton("???", Color.WHITE, SCREEN_WIDTH - Abutton.BUTTON_WIDTH - 20, y);

		//Reset our x, as we are making buttons above the others.
		x = 20;
		y -= Abutton.BUTTON_WIDTH; //Right above our current buttons.

		redB = new Abutton("Red", Color.red, x, y);
		x += Abutton.BUTTON_WIDTH * 1.5;
		greenB = new Abutton("Green", Color.green, x, y);
		x += Abutton.BUTTON_WIDTH * 1.5;
		blueB = new Abutton("Blue", Color.blue, x, y);
		x += Abutton.BUTTON_WIDTH * 1.5;
		magentaB = new Abutton("Magenta", Color.magenta, x, y);
		x += Abutton.BUTTON_WIDTH * 1.5;
		whiteB = new Abutton("White", Color.white, x, y);
		transB = new Abutton("Transparent", Color.white, SCREEN_WIDTH - Abutton.BUTTON_WIDTH - 20, y);

		//End block.

		platforms = new Collection();

		enemies = new Collection();
		totalPlatforms = 0; //Have none at first.
		running = false; //Not running animation.
		delay = 35; //Speed of program. Lower = faster.
		time = 0; //Total time that has elapsed.
		score = 0; //Total score
		highScore = 0;
		highTime = 0;

		difficulty = 1; //In case no difficulty was selected at startup.

		playerColor = Color.red; //In case we don't hit any buttons for color.

		//Animation.
		alarm = new Alarm(this);
		alarm.setPeriod(delay);
		alarm.start();

		//Drawing
		createBufferStrategy(2);
		buffer = getBufferStrategy();

		left = right = false; //Not moving at beginning.
		keyPressed = false; //We are not pressing anything.
		heaven = true; //We fall down from the start.
	}

	/**
	 *	The only "graphical" method of the class is the paint method.
	 */
	public void paintFrame()
	{
		Graphics pane = buffer.getDrawGraphics();

		if (!running)
		{
			//Draw our background, high score, and time lasted.

			//Make variables for loop.
			int r, g, b;

			//Draw background
			for (int i = 0; i < 200; i++)
			{
				r = i + 55;
				g = i;
				b = i;
				pane.setColor(new Color(r, g, b));
				pane.fillRect(0, i*3, SCREEN_WIDTH, 20);
			}

			//Draw high score
			pane.setColor(Color.white);
			pane.drawString("High Score:", 10, 10);
			pane.drawString(String.valueOf(highScore), 10, 20);

			//Draw time lasted, in (approximate) seconds.
			pane.drawString("Most seconds lasted:", SCREEN_WIDTH - 200, 10);
			pane.drawString(String.valueOf((int)highTime/(delay - 10)), SCREEN_WIDTH - 200, 20);

			//Draw instructions.
			pane.drawString("Welcome to Perilous Platform Pacer! In this game, the goal is to"
					+ "stay away from the top and the bottom of the screen for as long as", 40, 100);
			pane.drawString("possible! First, you may choose any color you want your character to be. After, select"
					+ " your difficulty, and press enter to start!", 10, 115);
			pane.drawString("Your score will continually rise during the game, and higher difficulties"
					+ " mean higher scores! Whenever you are near the top or bottom,", 10, 130);
			pane.drawString("your score will receive a sudden boost in the rate it increases! "
					+ "Are you ready for the ups and downs this game has to offer?", 10, 145);
			pane.drawString("Can you control your character to safety, amongst the constant threats"
					+ "and hazards this world will throw at you?", 10, 160);
			pane.drawString("When you are ready for some serious platformer action,"
					+ " select a color and difficulty! Good luck, "
					+ "and I hope to see you at the...", 10, 175);

			//Setup for the word "bottom"
			//Word and background same as our color, to show what button we clicked last.
			pane.setColor(playerColor.darker().darker());
			pane.fillRect(SCREEN_WIDTH/2 - 10, SCREEN_HEIGHT/2 - 15, 70, 20);
			pane.setColor(playerColor);
			pane.drawString(" bottom...", SCREEN_WIDTH/2, SCREEN_HEIGHT/2);

			//Check and draw our difficulty.
			pane.setColor(Color.white);
			String strDifficulty = "";
			if (difficulty == 1)
				strDifficulty = "Easy";
			else if (difficulty == 2)
				strDifficulty = "Medium";
			else if (difficulty == 3)
				strDifficulty = "Hard";
			else if (difficulty == 5)
				strDifficulty = "Very Hard";
			else if (difficulty == 6)
				strDifficulty = "Are you kidding me?!";

			pane.drawString("The current difficulty is: " + strDifficulty, SCREEN_WIDTH/2 - 50, SCREEN_HEIGHT/2 + 40);

			//Draw our buttons.
			redB.paint(pane);
			greenB.paint(pane);
			blueB.paint(pane);
			magentaB.paint(pane);
			whiteB.paint(pane);
			transB.paint(pane);
			easyB.paint(pane);
			mediumB.paint(pane);
			hardB.paint(pane);
			vHardB.paint(pane);
			questionB.paint(pane);
		}

		else //We are running!
		{	

			//Draw background
			pane.setColor(bgColor);
			pane.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

			//Draw heaven and hell images.

			//Image code taken from javadocs
			if (heaven)
			{
				BufferedImage img = null; //Default if try block is not done.
				try { //In case file is not in directory
					img = ImageIO.read(new File("angel.png"));
				} catch (IOException e) {} //Do nothing if file is not found.

				pane.drawImage(img, SCREEN_WIDTH/8, 100, bgColor, null);
				pane.drawImage(img, (int)(SCREEN_WIDTH/1.5), SCREEN_HEIGHT - 200, bgColor, null);
			}

			else //We're in hell!!
			{
				//Draw demon image using same code.
				BufferedImage img = null; //Default if try block is not done.
				try { //In case file is not in directory
					img = ImageIO.read(new File("hellFire.jpg"));
				} catch (IOException e) {} //Do nothing if file is not found.

				pane.drawImage(img, 0, 0, bgColor, null);
			}

			//Draw score
			pane.setColor(Color.black);
			pane.drawString("Score:", 10, 10);
			pane.drawString(String.valueOf(score), 10, 20);

			//Draw time

			//This is for our seconds.
			int seconds = (int)time/(delay - 10);
			pane.drawString("Time: ", SCREEN_WIDTH - 100, 10);
			pane.drawString(String.valueOf(seconds), SCREEN_WIDTH - 100, 20);

			player.paint(pane);
			platforms.paint(pane);
			enemies.paint(pane);

			//We draw a circular indicator of our position if we reach the left or right edge of the screen.
			//This is for skilled outplays of platforms :)
			//Note that this code is placed here to ensure this circle gets drawn over everything.
			if (player.getX() + (player.getWidth()/2) - 5 >= SCREEN_WIDTH)
			{
				pane.setColor(Color.black); //Draw black ellipse
				pane.fillOval(SCREEN_WIDTH - 60, (int)player.getY(), 40, 40);
				pane.setColor(playerColor);
				//Draw our player with size reduced in the black ellipse.
				pane.fillRect(SCREEN_WIDTH - 50, (int)player.getY() + 10,
						(int)player.getWidth()/2, (int)player.getHeight());

				//This is so we can see ourselves inside a black little "indicator".
			}

			else if (player.getX() + (player.getWidth()/2) - 5 <= 0) //Same as above if condition.
			{
				pane.setColor(Color.black); //Draw black ellipse
				pane.fillOval(60, (int)player.getY(), 40, 40);
				pane.setColor(playerColor);

				//Draw our player with size reduced in the black ellipse.
				pane.fillRect(70, (int)player.getY() + 10,
						(int)player.getWidth()/2, (int)player.getHeight());
			}

			if (difficulty == 6) //??? Difficulty
			{
				pane.setColor(Color.red);
				pane.drawString("Good luck...", SCREEN_WIDTH/2, 10);
				//^ A reminder of your inevitable doom...
			}
		}

		pane.dispose(); //After we are done, dispose of our drawing tool
		buffer.show(); //Show everything we have drawn!
	}


	/**
	 *	In order to use an alarm, we need to provide a takeNotice method.
	 *	It will be invoked each time the alarm goes off. This method is what happens
	 *  when the game runs.
	 */
	public void takeNotice()
	{
		paintFrame();

		if (running)
		{
			//Useful to have the middle of the player's y position.
			double playerMiddleY = player.getY() + (player.getHeight()/2);

			time++;
			//Calculate rate of score increment by taking into account the difficulty and
			//how close we are to the bottom or top.
			int scoreIncrement = (int)(difficulty * 20);
			if (playerMiddleY < 50 ||
					playerMiddleY > (SCREEN_HEIGHT - 50)) //If we are close to top or bottom
				scoreIncrement += 200; //Rate of score increases

			double timeScale;

			//Change BG depending on time and difficulty
			if (difficulty == 1) //Easy
				timeScale = 200;
			else if (difficulty == 2) //Medium
				timeScale = 150;
			else if (difficulty == 3) //Hard
				timeScale = 100;
			else if (difficulty == 5)//Very Hard
				timeScale = 50;
			else //??? Difficulty
				timeScale = 25;

			//Changes BG color.
			changeBackground(timeScale);

			score += scoreIncrement; //Thus, as difficulty increases, so does our rate of score.

			if (totalPlatforms == 0) //No platforms
			{
				platforms.add(new Platform(player.getX() - 5, (player.getY() + player.getHeight()) + 50,
						50, 20, Color.green, 0, 1)); //Our starter, safe platform.
				totalPlatforms++;
			}

			if (time % 20 == 0) //Every 20 ticks.
			{
				addRandPlatform(timeScale);
				addRandEnemy();
			}

			handlePhysics(); //Handles all physical interactions.

			if (player.getY() + player.getHeight() <= 0 ||
					(player.getY()) > SCREEN_HEIGHT) //Reached the top or bottom of the screen.
			{
				end();
			}
			alarm.setPeriod(delay);
		}
	}

	/**
	 * This ends the game. Goes back to menu, and displays high score.
	 * Also resets all variables we have used in-game to their default values, or 0.
	 * Basically a reset method of sorts.
	 */
	public void end()
	{
		if (score > highScore)
			highScore = score; //Always record highest score of this instance.

		if (time > highTime)
			highTime = time; //Always record highest time of this instance.

		running = false; //We're not playing because we're dead :(

		//For the next game...
		score = 0;
		time = 0;
		platforms = new Collection();
		enemies = new Collection();
		totalPlatforms = 0;
		totalEnemies = 0;
		left = right = false; 
		keyPressed = false;
		bgColor = new Color(0, 255, 255); //Back to that cyan blue...
		heaven = true; //To hell and back!
	}

	/**
	 * Changes our background. What this means is that it changes the BG color and
	 * the speed of our platforms and enemies. This does NOT change the difficulty data member.
	 * @param timeScale The scale used to change things.
	 */
	private void changeBackground(double timeScale)
	{
		if (time%timeScale == 0 && heaven)
		{
			int bgRed = bgColor.getRed() + 5;
			int bgGreen = bgColor.getGreen() - 5;
			int bgBlue = bgColor.getBlue() - 5;

			if (! (bgRed > 255 && bgGreen < 0 && bgBlue < 0)) //Makes sure we have legal values
				bgColor = new Color(bgRed, bgGreen, bgBlue); //Decrease green and blue by 3
			else
				heaven = false; //We have gotten to red, so we are in hell now!
		}

	}

	/**
	 *	This method is a helper, and checks for and handles the physics of the game.
	 *	It also goes through the collections we have, making everything move.
	 */
	private void handlePhysics()
	{
		//Movement
		if (left)
			player.moveLeft();
		if (right)
			player.moveRight();

		Platform p;
		player.move(); //Basically makes us forever fall.
		while (platforms.hasNext())
		{
			p = (Platform)(platforms.next().getItem());
			if (p.getY() < 0) //Remove platforms that reach the top border.
				platforms.remove(p);
			p.move();

			if (player.collidesWith(p)) //Allows us to climb platforms
			{
				player.land();
				player.stayOnTop(p);
			}


			Enemy e;
			while (enemies.hasNext()) //Go through our enemies
			{
				e = (Enemy)(enemies.next().getItem()); //Cast so we can use methods
				if (player.collidesWith(e)) //Kill us
				{
					end();
				}
				e.move(player);
				
				if (e.getX() < 0 || e.getX() > SCREEN_WIDTH) //Right or left edge
				{
					enemies.remove(e); //Non-existent.
					totalEnemies--;
				}
			}
		}

		platforms.reset(); //Ensures loop keeps happening.
		enemies.reset();
	}

	/**
	 *	This is another helper method, that creates and adds a random platform.
	 *	It is used when we start the game.
	 *	@param timeScale To determine the speed scaling rate.
	 */
	private void addRandPlatform(double timeScale)
	{
		double difficultyScale;

		if (time < 1000)
		{
			difficultyScale	= (difficulty * (time/500)); //Max = 2 * difficulty
		}
		else if (time < 4000)
			difficultyScale	= (difficulty * (time/1333)); //Max = 3 * difficulty

		else if (time < 7000)
			difficultyScale	= (difficulty * (time/1500)); //Max = 4.66 * difficulty

		else
			difficultyScale = (6 * difficulty); //Max difficulty!

		//The order is x, y, width, height, color, xSpeed and ySpeed.

		//
		//Here we create a bunch of variables for use when we create a platform.
		//Note that this is just for readability, and all of these numbers could safely
		//be inserted into the constructor parameters.
		//
		double y = SCREEN_HEIGHT;
		double width = ((Math.random()*200)) + 10;
		double x = 150 + (Math.random() * (SCREEN_WIDTH - 350)); //Range: 150 to 600 if SCREEN_WIDTH = 800
		double height = 30;

		double ySpeed = ((Math.random() * 2) + 1) + (difficultyScale/2); //+1 prevents having an ySpeed of 0
		int r = (int)(Math.random()*255);
		int g = (int)(Math.random()*255);
		int b = (int)(Math.random()*255);
		Color color = new Color(r, g, b);


		//DEBUG
		//System.out.println(bounce);

		//Now we use all that stuff above

		Platform p = new Platform(x, y, width, height, color, 0, ySpeed);
		platforms.add(p);
		totalPlatforms++;
	}

	/**
	 * This adds a random enemy to the enemies collection.
	 */
	public void addRandEnemy()
	{
		int rand = (int)(Math.random() * 2);
		double x = 20 + (Math.random() * SCREEN_WIDTH - 90); //20 to SCREEN_WIDTH - 90
		double y;

		if (rand == 1) //Create at top.
			y = 0;
		else
			y = SCREEN_HEIGHT; //Create at bottom.

		if (time % 1200 == 0) //Enemies been here long enough
		{
			for (int i = 0; i < totalEnemies; i++)
			{
				enemies.remove();
			}
			totalEnemies = 0;
		}

		if (time % 100 == 0) //Create bowling ball.
		{
			if (x < SCREEN_WIDTH/2) //If gonna spawn around left side.
			{
				double realX = 0; //Spawn at left, moving right.
				enemies.add(new BowlingBall(realX, player.getY(), 5 * difficulty, 5 * difficulty,
						Color.black, 5, 0));
			}
			else
			{
				double realX = SCREEN_WIDTH; //Spawn at right, moving left.
				enemies.add(new BowlingBall(realX, player.getY(), 5 * difficulty, 5 * difficulty,
						Color.black, -5, 0));
			}
			totalEnemies++;
		}

		if (time%200 == 0) //Create homing monster.
		{
			enemies.add(new HomingMonster(x, y,
					5 * difficulty, 5 * difficulty, Color.darkGray, 2, 5));
			totalEnemies++;
		}
	}

	/**
	 *	The check method checks where the mouse is been clicked.
	 *	Each button has its own action implemented here.
	 */
	private void check()
	{
		if (!running)
		{
			//Set our colors
			if (redB.isInside(lastX, lastY))
			{
				playerColor = Color.red;
			}
			else if (greenB.isInside(lastX, lastY))
			{
				playerColor = Color.green;
			}
			else if (blueB.isInside(lastX, lastY))
			{
				playerColor = Color.blue;
			}
			else if (magentaB.isInside(lastX, lastY))
			{
				playerColor = Color.magenta;
			}

			else if (whiteB.isInside(lastX, lastY))
			{
				playerColor = Color.white;
			}

			else if (transB.isInside(lastX, lastY))
			{
				playerColor = new Color(0, 0, 0, 0); //Can change our color to nothing, as we
				//are not a color. The alpha is made to be 0 for transparent.
			}

			//Difficulties
			if (easyB.isInside(lastX, lastY))
				difficulty = 1;

			else if (mediumB.isInside(lastX, lastY))
				difficulty = 2;

			else if (hardB.isInside(lastX, lastY))
				difficulty = 3;

			else if (vHardB.isInside(lastX, lastY))
				difficulty = 5;

			else if (questionB.isInside(lastX, lastY))
				difficulty = 6;
		}
	}

	/**
	 * This is basically the check method, but for keyboard.
	 * @param key The key code gotten from the methods implemented from KeyListener.
	 */
	private void checkKeyboard(int key)
	{		
		if (key == KeyEvent.VK_LEFT)
		{
			left = !left; //So true, and then false, etc.
		}

		else if (key == KeyEvent.VK_RIGHT)
		{
			right = !right;
		}
	}

	//
	//	M o u s e L i s t e n e r
	//	=========================
	//
	//	The implementation of the MouseListener requires the implementation of the
	//		following five methods.  Each method deals with a particular event
	//		associated with the mouse.
	//
	//	mouseClicked:	invoked when the mouse button is pressed and released at the
	//					same location.
	//	mousePressed:	invoked when the mouse button is pressed down
	//	mouseReleased:	invoked when the mouse button is released
	//	mouseEntered:	invoked when the mouse pointer moves into a component
	//					(i.e., the Frame)
	//	mouseExited:	invoked when the mouse pointer moves out of a component
	//
	//	Note that we are "listening" to mouse events that occur in conjunction with the
	//		Frame that implements the methods associated with the mouse.  If your
	//		application has several frames, each frame can deal with its own mouse
	//		events in completely independent ways.
	//

	/**
	 * This does the check method, which basically does what the buttons should do.
	 * @param event The mouse.
	 */
	public void mouseClicked(MouseEvent event)
	{
		check();								//	Handle the mouse click
	}

	/**
	 * This method flips any button you hit.
	 * @param event The mouse.
	 */
	public void mousePressed(MouseEvent event)
	{
		lastX = event.getX();					//	Update the mouse location
		lastY = event.getY();

		flipWhenInside();						//	Flip any button hit by the mouse
	}

	/**
	 * Whenever you release your click, flip the buttons that needed to be flipped.
	 * @param event The mouse.
	 */
	public void mouseReleased(MouseEvent event)
	{
		flipWhenInside();
	}

	/**
	 * Not needed.
	 * @param event The mouse.
	 */
	public void mouseEntered(MouseEvent event) {}

	/**
	 * Not needed.
	 * @param event The mouse.
	 */
	public void mouseExited(MouseEvent event) {}

	/**
	 * Flips the buttons, is a helper method of mousePressed and mouseReleased.
	 */
	private void flipWhenInside()
	{
		//This method simply flips
		if (redB.isInside(lastX, lastY))
			redB.flip();
		else if (greenB.isInside(lastX, lastY))
			greenB.flip();
		else if (blueB.isInside(lastX, lastY))
			blueB.flip();
		else if (magentaB.isInside(lastX, lastY))
			magentaB.flip();
		else if (whiteB.isInside(lastX, lastY))
			whiteB.flip();
	}

	/**
	 * This method checks whether you are pressing a key. Will be used for 
	 * determining whether we move left, right, or jump.
	 * @param e The KeyEvent
	 */
	public void keyPressed(KeyEvent e) {

		//Only call once.
		if (running && !keyPressed)
		{
			keyPressed = true;
			checkKeyboard(e.getKeyCode());
		}

		if (!running && !keyPressed) //At main screen.
			if (e.getKeyCode() == KeyEvent.VK_ENTER)
			{
				//Starts our game, and makes our player.
				if (difficulty == 1)
					player = new Player(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, 40, 20, playerColor);

				else if (difficulty == 2)
					player = new Player(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, 30, 20, playerColor);

				else if (difficulty == 3)
					player = new Player(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, 25, 20, playerColor);

				else if (difficulty == 5)
					player = new Player(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, 15, 20, playerColor);

				else if (difficulty == 6)
					player = new Player(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, 5, 5, playerColor);

				running = true;
				keyPressed = true;
			}
	}

	/**
	 * Similar to the keyPressed method, but does the exact opposite.
	 * @param e The KeyEvent
	 */
	public void keyReleased(KeyEvent e) {

		if (running && keyPressed)
		{
			keyPressed = false;
			checkKeyboard(e.getKeyCode());
		}
	}

	/**
	 * This will not be used.
	 * @param e The KeyEvent.
	 */
	public void keyTyped(KeyEvent e) {

	}

}	//	end of class
