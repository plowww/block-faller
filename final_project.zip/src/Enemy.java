import java.awt.*;

/**
 * This is the basis of every hazard in the game. It will define the behavior for when an
 * enemy touches the player, as well as provide extra data members for enemies.
 * @author Kevin Gomes
 *
 */
public abstract class Enemy extends Entity {

	/**
	 * This is how fast the enemy moves in the x plane.
	 */
	protected double xSpeed;
	
	/**
	 * This is how fast the enemy moves in the y plane.
	 */
	protected double ySpeed;
	
	/**
	 * The default constructor creates our enemy at the top left, with a speed of 2.
	 */
	public Enemy()
	{
		super();
		xSpeed = 2;
		ySpeed = 2;
	}
	
	/**
	 * Our main constructor creates an enemy at a given x and y position,
	 * with a given width and height. It then takes a color and speed.
	 * @param xPos The x-coordinate of our enemy.
	 * @param yPos The y-coordinate of our enemy.
	 * @param w The width of our enemy.
	 * @param h The height of our enemy.
	 * @param c The color of our enemy.
	 * @param xS The x speed of our enemy.
	 * @param yS The y speed of our enemy.
	 */
	public Enemy(double xPos, double yPos, double w, double h, Color c, double xS, double yS)
	{
		super(xPos, yPos, w, h, c);
		xSpeed = xS;
		ySpeed = yS;
	}
	
	/**
	 * This is for polymorphism. This makes every enemy have a way of moving,
	 * and allows us to call any given enemy's move method with our collection.
	 * All enemies will take into account the player's position in some way.
	 * @param p The player.
	 */
	public abstract void move(Entity p);
	
	/**
	 * Like entity, this method is to ensure that all enemies have their own paint method.
	 * @param pane The thing used for drawing.
	 */
	public abstract void paint(Graphics pane);
}
