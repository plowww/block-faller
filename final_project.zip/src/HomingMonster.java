import java.awt.*;

/**
 * This class can create a rectangular moving enemy that goes towards 
 * whatever entity passed in its move method. It flies and does not take into account
 * anything in its way.
 * @author Kevin Gomes
 *
 */
public class HomingMonster extends Enemy {

	/**
	 * Default, same as Enemy.
	 */
	public HomingMonster()
	{
		super();
	}

	/**
	 * Our main constructor creates an enemy at a given x and y position,
	 * with a given width and height. It then takes a color and speed.
	 * @param xPos The x-coordinate of our enemy.
	 * @param yPos The y-coordinate of our enemy.
	 * @param w The width of our enemy.
	 * @param h The height of our enemy.
	 * @param c The color of our enemy.
	 * @param xS The x speed of our enemy.
	 * @param yS The y speed of our enemy.
	 */
	public HomingMonster(double xPos, double yPos, double w, double h, Color c, double xS, double yS)
	{
		super(xPos, yPos, w, h, c, xS, yS);
	}

	/**
	 * This moves our monster towards whatever entity was given.
	 * It doesn't continuously follow this entity however,
	 * as a random value will dictate whether this method does anything.
	 * @param e The entity we are following.
	 */
	public void move(Entity e)
	{
		int rand = (int)(Math.random() * 5); //To make it not ALWAYS follow the player.
		//Makes enemy sporadic and thus unpredictable.

		if (rand == 0)
		{
			if (x < e.getX())
				x += xSpeed;
			else
				x -= xSpeed;
			if (y < e.getY())
				y += ySpeed;
			else
				y -= ySpeed;
		}
	}
	
	/**
	 * Draws our monster. This is made up of a rectangle body, two eyes, and a arc for a smile.
	 */
	public void paint(Graphics pane)
	{
		pane.setColor(color);
		pane.fillRect((int)x, (int)y, (int)width, (int)height);
		pane.setColor(color.brighter().brighter());
		pane.fillOval((int)(x + (width/4)), (int)(y + (height/6)), (int)width/6, (int)height/6); //Left eye
		pane.fillOval((int)(x + (width/2)), (int)(y + (height/6)), (int)width/6, (int)height/6); //Right eye
		pane.fillArc((int)x, (int)(y + (height/2)), (int)width, (int)height/2, 0, -180); //Mouth. From > to <,
		//makes a smile.
	}
}
