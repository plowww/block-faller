import java.awt.event.*;
/** Allows windows to be closed with the X button.
 * 
 * @author Kevin Gomes
 *
 */

public class Window extends WindowAdapter {
	
	/**
	 * So our window closes when the user hits the close button.
	 */
	public void windowClosing(WindowEvent event){
		System.exit(0);
	}
}
