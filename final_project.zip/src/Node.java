import java.awt.*;

/**
 * A node is a data type that we will use for our collection of floors. It will have a way to
 * get the next node, and the item stored within. This item is an entity.
 * @author Kevin Gomes
 *
 */
public class Node {
	
	/**
	 * Holds the reference to our object.
	 */
	private Entity item;
	
	/**
	 * Has the next node.
	 */
	private Node next;
	
	/**
	 * The default constructor creates a blank node with no item, and the reference points to null.
	 */
	public Node()
	{
		item = null;
		next = null;
	}
	
	/**
	 * The main constructor creates a node and stores the item given into it, and refers to
	 * whatever is passed as next.
	 * @param item The item to be stored in this node.
	 * @param next The node that this node will point to.
	 */
	public Node(Entity item, Node next)
	{
		this.item = item;
		this.next = next;
	}
	
	/**
	 * Gives us the next node.
	 * @return next
	 */
	public Node getNext()
	{
		return next;
	}
	
	/**
	 * Makes our node point to the node passed.
	 * @param next The node we want our node to point to.
	 */
	public void setNext(Node next)
	{
		this.next = next;
	}
	
	/**
	 * Gives us the entity stored within the node.
	 * @return The entity inside of our node.
	 */
	public Entity getItem()
	{
		return item;
	}
	
	/**
	 * Sets the item of our node to whatever we pass.
	 * @param item The item that will be set.
	 */
	public void setItem(Entity item)
	{
		this.item = item;
	}
	
	/**
	 * Draws the item contained within our node.
	 * @param pane For drawing.
	 */
	public void paint(Graphics pane)
	{
		item.paint(pane);
	}
}

