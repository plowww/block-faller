import java.awt.*;
import java.awt.event.*;

/**
 * The Abutton class creates a fully functioning button, with a color, text, and size.
 * We can also flip it when we click.
 */
public class Abutton
{
	public static final
		int BUTTON_WIDTH = 72,		//	To define a "standard" size button
			BUTTON_HEIGHT = 30;

	/**
	 *	Constructor
	 *	============
	 *
	 *	Instantiates a button from scratch.
	 * 
	 */
	public Abutton()
	{
		this("?????", Color.black, 100, 100);
	}

	/**
	 * Creates a button with the default width and height.
	 * @param someLabel The text displayed.
	 * @param someColor The color of the button.
	 * @param someX The x position of the button.
	 * @param someY The y position of the button.
	 */
	public Abutton(String someLabel, Color someColor,
					  int someX, int someY)
	{
		this(someLabel, someColor, someX, someY,
				BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	/**	Instantiates a button given all its components.
	 * 
	 * @param someLabel The text on the button.
	 * @param someColor The color filled in.
	 * @param someX The x position.
	 * @param someY The y position.
	 * @param someWidth The width.
	 * @param someHeight The height.
	 */
	public Abutton(String someLabel, Color someColor,
					  int someX, int someY,
					  int someWidth, int someHeight)
	{
		setup(someLabel, someColor, someX, someY,
				someWidth, someHeight);
	}

	/**
	 * This sets up our button, initializing values.
	 * @param someLabel The text displayed on our button.
	 * @param someColor The color of our button.
	 * @param someX The x position of our button.
	 * @param someY The y position of our button.
	 * @param someWidth The width.
	 * @param someHeight The height.
	 */
	public void setup(String someLabel, Color someColor,
					  int someX, int someY,
					  int someWidth, int someHeight)
	{
		theLabel = someLabel;
		theColor = someColor;
		x = someX;
		y = someY;
		width = someWidth;
		height = someHeight;
		up = true;
	}

	/**
	 *	Flips the up/down state of a button (for 3-D effects).
	 */
	public void flip()
	{
		up = ! up;
	}

	/**
	 *	Determines if a given point is inside a button.
	 *	Note:  The boundary is considered within (inside) the button.
	 *	@param someX The x position that will be used for checking.
	 *  @param someY The y position that will be used for checking.
	 *  @return Whether the someX and someY are within the button.
	 */
	public boolean isInside(int someX, int someY)
	{
		return ((someX >= x) && (someX <= x + width)
				&& (someY >= y) && (someY <= y + height));
	}

	/**
	 *	Draws a button.
	 *	@param pane For drawing.
	 */
	public void paint(Graphics pane)
	{
		final int DELTA = 2;				//	To define the space between the
											//		frame and the inside of a button

		pane.setColor(Color.black);			//	Drawing the button frame
		pane.drawRect(x, y, width, height);	//		in black,

		pane.setColor(theColor);			//	and the inside of the button
		pane.fill3DRect(x + DELTA, y + DELTA,	//	in the button color
						width - (2*DELTA - 1),
						height - (2*DELTA - 1),
						up);

		pane.setColor(Color.black);			//	Finally, we put the label in black
											//		... and nicely centered
		int labelWidth = pane.getFontMetrics().stringWidth(theLabel);
		int labelHeight = pane.getFontMetrics().getAscent();
		pane.drawString(theLabel,
						x + (width - labelWidth)/2,
						y + (height + labelHeight)/2);
	}

/**
 *	This is our text for the button.
 */
	private String theLabel;		
	
	/**
	 * This is our color for the button.
	 */
	private Color theColor;
	
	/**
	 * These are our x position, y position, width and hegith of the button.
	 */
	private int x, y, width, height;			

	/**
	 * For making the button seem like it's pressed down.
	 */
	private boolean up;

}	//	end Abutton