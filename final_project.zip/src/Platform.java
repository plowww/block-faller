import java.awt.*;

/**
 * The platform class is the main object of our game. This will be where we make our 
 * platforms. Each platform will rise upwards, and thus have a y speed that is negative.
 * Some may move left and right, and thus will have an xSpeed.
 * @author Kevin Gomes
 *
 */
public class Platform extends Entity {

	/**
	 * This is the x speed of our platform. For the most part, it is 0,
	 * but some platforms may move left and right.
	 */
	private double xSpeed;
	
	/**
	 * This is the ySpeed of the platform. It should be negative at all times,
	 * but may turn positive if we have funky platforms.
	 */
	private double ySpeed;

	/**
	 * The default constructor creates our platform at the bottom left of the screen, with a y speed of -2.
	 */
	public Platform()
	{
		super();
		xSpeed = 0;
		ySpeed = -2;
	}
	
	/**
	 * Our main constructor creates a platform at a given x and y position,
	 * with a given width and height. It then takes a color and speed.
	 * @param xPos The x-coordinate of our platform.
	 * @param yPos The y-coordinate of our platform.
	 * @param w The width of our platform.
	 * @param h The height of our platform.
	 * @param c The color of our platform.
	 * @param xS The x speed of our platform.
	 * @param yS The y speed of our platform.
	 */
	public Platform(double xPos, double yPos, double w, double h, Color c, double xS, double yS)
	{
		super(xPos, yPos, w, h, c);
		xSpeed = xS;
		ySpeed = yS;
	}
	
	/**
	 * This move method simply changes our position by our xSpeed and our ySpeed.
	 * It subtracts ySpeed and increases xSpeed (moves right and up).
	 */
	public void move()
	{
		x += xSpeed;
		y -= ySpeed;
	}
	
	/**
	 * The equals method uses entity's implementation as well as a few extra parameters.
	 * @param p The platform we are comparing ourselves to.
	 * @return Whether every data member is equal to platform "p".
	 */
	public boolean equals(Platform p)
	{
		return (super.equals(p) && xSpeed == p.xSpeed && ySpeed == p.ySpeed);
	}
	
	/**
	 * This draws our platform.
	 * @param pane For drawing.
	 */
	public void paint(Graphics pane)
	{
		//Outline
		pane.setColor(Color.black);
		pane.drawRect((int)(x), (int)(y), (int)width, (int)height);
		
		//Actual platform.
		pane.setColor(color);
		pane.fillRect((int)(x + 1), (int)(y + 1), (int)(width - 1), (int)(height - 1));
		
	}
	
	/**
	 * Prints out the x, y, and ySpeed of our platform. Is not used in game,
	 * but can be used for debugging.
	 */
	public String toString()
	{
		String s = "x: " + x + ", y: " + y + ", ySpeed: " + ySpeed;
		return s;
	}
}
