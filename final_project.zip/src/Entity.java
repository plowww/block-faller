import java.awt.*;

/**
 * The entity class is what many objects will inherit from. Almost every interactable object
 * in the game will inherit from this, as everything that is draw needs an x, y, width, height and color.
 * The entity can also check for collision with another entity, and return whether it happens or not.
 * @author Kevin Gomes
 *
 */
public abstract class Entity {

	/**
	 * This is our x position on the screen. It is a double to improve accuracy.
	 */
	protected double x;
	
	/**
	 * This is our y position on the screen. It is a double to improve accuracy.
	 */
	protected double y;
	
	/**
	 * This is our width. It determines how wide our object is.
	 */
	protected double width;
	
	/**
	 * This is our height. It determines how tall our object is.
	 */
	protected double height;
	
	/**
	 * This defines our color.
	 */
	protected Color color;
	
	/**
	 * The default constructor creates an entity at the top left, with 20 width and height, and black color.
	 */
	public Entity()
	{
		x = 0;
		y = 0;
		width = 20;
		height = 20;
		color = Color.black;
	}
	
	/**
	 * Our main constructor creates an entity at a given x and y position,
	 * with a given width and height, and finally a color.
	 * @param xPos The x-coordinate of our entity.
	 * @param yPos The y-coordinate of our entity.
	 * @param w The width of our entity.
	 * @param h The height of our entity.
	 * @param c The color of our entity.
	 */
	public Entity(double xPos, double yPos, double w, double h, Color c)
	{
		x = xPos;
		y = yPos;
		width = w;
		height = h;
		color = c;
	}
	
	/**
	 * This method gets our x position on the screen. Useful for collision checking, as well as
	 * finding when an object is left or right of another object.
	 * @return The x position.
	 */
	public double getX()
	{
		return x;
	}
	
	/**
	 * This method gets our y position on the screen. Useful for collision checking, as well as
	 * finding when an object is above or below another object.
	 * @return The y position.
	 */
	public double getY()
	{
		return y;
	}
	
	/**
	 * This method gets our width.
	 * @return The width.
	 */
	public double getWidth()
	{
		return width;
	}
	
	/**
	 * This returns us the height.
	 * @return The height.
	 */
	public double getHeight()
	{
		return height;
	}
	
	/**
	 * This method checks for collision between two entities. It returns true whether two
	 * entities are colliding. The entity that calls this method is checking if it is touching the
	 * entity passed as an argument. This assumes the entity is rectangular, and won't be as accurate
	 * with ellipses.
	 * @param e The second entity that the first is checking.
	 * @return Whether we collide with entity e.
	 */
	public boolean collidesWith(Entity e)
	{
		boolean result = false;
		if ((x + width >= e.x && x < e.x + e.width) && 
				(y + height >= e.y && y < e.y + e.height))
		{
			result = true;
		}
		
		return result;
	}
	
	/**
	 * This method ensures that every entity can draw itself.
	 * @param p The pane, or the thing used for drawing.
	 */
	public abstract void paint(Graphics p);
	
	/**
	 * This method ensures that every entity can find whether another entity is equal to it.
	 * To be used for removing specific items in lists, or determining if two things are identical.
	 * @param e The entity we are comparing ourselves to.
	 * @return Whether our data members and anything else we consider is equal or not.
	 */
	public boolean equals(Entity e)
	{
		return (x == e.x && y == e.y && width == e.width && height == e.height);
	}
	
	/**
	 * This compares to the width of another entity.
	 * Tells us if it is less than, equal, or greater than the entity.
	 * @param e The entity to which we compare ourselves to.
	 * @return -1 if less than, 0 if equal, 1 if greater than.
	 */
	public int compareToWidth(Entity e)
	{
		if (width < e.width)
			return -1;
		
		else if (width > e.width)
			return 1;
		else
			return 0;
	}

}
