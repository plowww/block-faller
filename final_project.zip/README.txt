When extracting the contents of this zip folder, make CERTAIN that the two images "angel.png"
and "hellFire.jpg" are located OUTSIDE of the "src" folder. This is to allow the loading of
these two images.

Enjoy!